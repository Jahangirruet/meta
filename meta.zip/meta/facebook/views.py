from django.shortcuts import render

from django.http import HttpResponse


from .models import Person

def index(request):

    person1 = Person()
    person1.name= "Jahangir"
    person1.phone= 123456789

    person2 = Person()
    person2.name= "Jahangir"
    person2.phone= 123456789

    persons =   [person1 , person2]

    return render(request,'home.html',{'persons':persons})
